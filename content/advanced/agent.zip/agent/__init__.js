create_action = pyodide.runPython(`
    from agent import *
    agent = Agents()
    agent`);
