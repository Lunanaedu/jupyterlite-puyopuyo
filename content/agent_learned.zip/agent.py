import numpy as np
import random
from puyopuyo import *
import dezero_emb as dezero

class DQNet(dezero.Models.Model):
  def __init__(self):
    super().__init__()
    self.l1 = dezero.L.Linear(128)
    self.l2 = dezero.L.Linear(128)
    self.l3 = dezero.L.Linear(1)

  def forward(self, x):
    x = dezero.F.relu(self.l1(x))
    x = dezero.F.relu(self.l2(x))
    x = self.l3(x)
    return x

class DQNAgent:
    def __init__(self):
        self.action_size = 2
        self.qnet = DQNet()

    def __call__(self, board_list, puyo_c):
        board_list = board_list.to_py()
        board = np.zeros(CFG.Height * CFG.Width, dtype=np.int32).reshape(CFG.Height, CFG.Width)
        for i in range(CFG.Height):
            for j in range(CFG.Width):
                if board_list[i][j] != None:
                    board[i][j] = int(board_list[i][j]['puyo']) 
        puyo = Puyopuyo()
        puyo.centerPuyo = puyo_c[0]
        puyo.movablePuyo = puyo_c[1]

        action = self.learned_agent(board, puyo)
        action[1] = action[1] * 90
        return action




    def learned_agent(self, board, puyo):
        action_list = utils.create_action_list(board)
        next_boards = []
        next_reward =[]
        action =(2, 1)
        if len(action_list):
            for action in action_list:
                next_board, reward, done = utils.next_board(board, puyo, action)
                if not done:
                    next_boards.append(next_board)
                    next_reward.append(reward)
        
        next_boards = np.stack(next_boards)
        predictions = self.eval2(next_boards)
        
        next_reward =np.array(next_reward)[:, np.newaxis]
        predictions += dezero.Variable(next_reward)
        index = predictions.data.argmax()
        action = action_list[index]
        return action

    def boardtostate(self, board):
        cont_b = 2 ** np.arange(CFG.Width,dtype=np.int32)
        b1 = np.zeros(CFG.Height * CFG.Width,dtype = np.int32).reshape(CFG.Height , CFG.Width)
        b1[board == 1] = 1
        b2 = np.zeros(CFG.Height * CFG.Width,dtype = np.int32).reshape(CFG.Height , CFG.Width)
        b2[board == 2] = 1
        b3 = np.zeros(CFG.Height * CFG.Width,dtype = np.int32).reshape(CFG.Height , CFG.Width)
        b3[board == 3] = 1
        b4 = np.zeros(CFG.Height * CFG.Width,dtype = np.int32).reshape(CFG.Height , CFG.Width)
        b4[board == 4] = 1
        board_list =np.concatenate([b1,b2,b3,b4])
        state =  board_list.dot(cont_b)      
        return state

    def eval(self, board):
        state = self.boardtostate(board)      
        return self.qnet(state)

    def eval2(self, boards):
        states = []
        for i in range(boards.shape[0]):
            state = self.boardtostate(boards[i])
            states.append(state)
        states = np.stack(states)      
        return self.qnet(states)

    def load_model(self,filename):
        self.qnet.load_weights(filename)


