create_action = pyodide.runPython(`
    from agent import *
    agent = DQNAgent()
    agent.load_model('puyopuyo.npz')
    agent`);
